package jaffa.archive;

public class SeatOutOfBoundsException extends Exception {

	private static final long serialVersionUID = 1L;

}
