package jaffa.weather16Day;

public class CurrentWeather {

	private List[] list;
	//private Temp temp;
	//private Weather[] weather;

	public CurrentWeather(){
		list = new List[16];
		//temp = new Temp();
		//weather = new Weather[10];
	}

	public List[] getList(){
		return list;
	}

	/*public Temp getTemp(){
		return temp;
	}

	public Weather getWeather(){
		return weather[0];
	}*/

}
