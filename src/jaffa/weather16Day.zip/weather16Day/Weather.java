package jaffa.weather16Day;

public class Weather {

	private String description;
	private String icon;

	public String getDescription(){
		return description;
	}

	public String getIcon(){
		return icon;
	}

}
