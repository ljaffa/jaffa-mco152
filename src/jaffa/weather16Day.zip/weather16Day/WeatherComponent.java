package jaffa.weather16Day;

import javax.swing.JComponent;
import javax.swing.JLabel;

public class WeatherComponent extends JComponent{

	//all things to display
	private JLabel date;
	private JLabel temp;
	private JLabel desc;
	private JLabel icon;

	public WeatherComponent(){
		this.date = new JLabel();
		this.temp = new JLabel();
		this.desc = new JLabel();
		this.icon = new JLabel();
	}


}
