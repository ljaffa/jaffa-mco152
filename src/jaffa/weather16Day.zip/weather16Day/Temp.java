package jaffa.weather16Day;

public class Temp {

	private double day;

	public double getDayTemp(){
		return day;
	}

}
