package jaffa.weather;

public class Main {

	private double temp;

	public double getTemp(){
		return temp;
	}

}
