package jaffa.weather;

import java.io.IOException;

public class WeatherMain {

	public static void main(String[] args) throws IOException{

		WeatherGui gui = new WeatherGui();

		gui.setVisible(true);
	}

}
